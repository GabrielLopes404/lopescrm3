import type { UserRole } from "@shared/schema";

export function isUnauthorizedError(error: Error): boolean {
  return /^401: .*Unauthorized/.test(error.message);
}

export function canViewFinancials(role: UserRole | undefined): boolean {
  return role === "admin" || role === "gerente";
}

export function canEditData(role: UserRole | undefined): boolean {
  return role === "admin" || role === "gerente";
}

export function canDeleteData(role: UserRole | undefined): boolean {
  return role === "admin";
}

export function canManageUsers(role: UserRole | undefined): boolean {
  return role === "admin";
}

export function getRoleName(role: UserRole | undefined): string {
  switch (role) {
    case "admin":
      return "Administrador";
    case "gerente":
      return "Gerente";
    case "funcionario":
      return "Funcionário";
    default:
      return "Usuário";
  }
}

export function getRoleBadgeColor(role: UserRole | undefined): string {
  switch (role) {
    case "admin":
      return "bg-chart-3 text-white";
    case "gerente":
      return "bg-chart-4 text-white";
    case "funcionario":
      return "bg-chart-2 text-white";
    default:
      return "bg-muted text-muted-foreground";
  }
}
