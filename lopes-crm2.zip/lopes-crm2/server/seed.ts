import { storage } from "./storage";
import { hashPassword } from "./auth";

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "gabriel.lopesfarm70@gmail.com";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "Farmtwo70%16446620";

export async function seedAdmin(): Promise<void> {
  try {
    const existingAdmin = await storage.getUserByEmail(ADMIN_EMAIL);
    
    if (existingAdmin) {
      console.log("Admin user already exists");
      return;
    }

    const hashedPassword = await hashPassword(ADMIN_PASSWORD);

    await storage.createUser({
      email: ADMIN_EMAIL,
      password: hashedPassword,
      firstName: "Gabriel",
      lastName: "Lopes",
      role: "admin",
      isActive: true,
    });

    console.log(`Admin user created: ${ADMIN_EMAIL}`);
  } catch (error) {
    console.error("Error seeding admin:", error);
  }
}
