import session from "express-session";
import type { Express, Request, Response, NextFunction, RequestHandler } from "express";
import connectPg from "connect-pg-simple";
import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { loginSchema } from "@shared/schema";
import { z } from "zod";

const SALT_ROUNDS = 12;
const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_TIME = 15 * 60 * 1000; // 15 minutes

declare module "express-session" {
  interface SessionData {
    userId: string;
    userRole: string;
    csrfToken: string;
  }
}

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  
  return session({
    secret: process.env.SESSION_SECRET || "fallback-secret-change-in-production",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    name: "lopes.sid",
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: sessionTtl,
    },
  });
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

function generateCsrfToken(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < 32; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

function sanitizeInput(input: string): string {
  return input
    .replace(/[<>'"]/g, '')
    .trim()
    .slice(0, 1000);
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());

  // CSRF token generation for all requests
  app.use((req, res, next) => {
    if (!req.session.csrfToken) {
      req.session.csrfToken = generateCsrfToken();
    }
    next();
  });

  // Login route
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const validation = loginSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Dados inválidos",
          errors: validation.error.flatten().fieldErrors 
        });
      }

      const { email, password } = validation.data;
      const sanitizedEmail = sanitizeInput(email).toLowerCase();
      
      const user = await storage.getUserByEmail(sanitizedEmail);
      
      if (!user) {
        return res.status(401).json({ message: "Email ou senha incorretos" });
      }

      // Check if account is locked
      if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
        const remainingTime = Math.ceil((new Date(user.lockedUntil).getTime() - Date.now()) / 60000);
        return res.status(423).json({ 
          message: `Conta bloqueada. Tente novamente em ${remainingTime} minutos.` 
        });
      }

      // Check if user is active
      if (!user.isActive) {
        return res.status(403).json({ message: "Conta desativada. Contate o administrador." });
      }

      // Verify password
      const isValidPassword = await verifyPassword(password, user.password);
      
      if (!isValidPassword) {
        const newAttempts = (user.loginAttempts || 0) + 1;
        
        if (newAttempts >= MAX_LOGIN_ATTEMPTS) {
          await storage.lockUserAccount(user.id, new Date(Date.now() + LOCK_TIME));
          return res.status(423).json({ 
            message: "Muitas tentativas. Conta bloqueada por 15 minutos." 
          });
        }
        
        await storage.incrementLoginAttempts(user.id, newAttempts);
        return res.status(401).json({ message: "Email ou senha incorretos" });
      }

      // Reset login attempts and update last login
      await storage.resetLoginAttempts(user.id);
      await storage.updateLastLogin(user.id);

      // Create session
      req.session.userId = user.id;
      req.session.userRole = user.role;
      req.session.csrfToken = generateCsrfToken();

      // Log activity
      await storage.createActivityLog({
        action: "login",
        entityType: "user",
        entityId: null,
        details: "Login realizado com sucesso",
        ipAddress: req.ip || req.socket.remoteAddress || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: user.id,
      });

      // Return user data (without password)
      const { password: _, ...userWithoutPassword } = user;
      res.json({ 
        user: userWithoutPassword,
        csrfToken: req.session.csrfToken 
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });

  // Logout route
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const userId = req.session.userId;
    
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Erro ao sair" });
      }
      
      res.clearCookie("lopes.sid");
      res.json({ message: "Logout realizado com sucesso" });
    });
  });

  // Get current user
  app.get("/api/auth/user", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Não autenticado" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Erro ao buscar usuário" });
    }
  });

  // Get CSRF token
  app.get("/api/auth/csrf", (req: Request, res: Response) => {
    res.json({ csrfToken: req.session.csrfToken });
  });
}

// Middleware: Check if authenticated
export const isAuthenticated: RequestHandler = (req, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Não autenticado" });
  }
  next();
};

// Middleware: CSRF protection for mutating requests
export const csrfProtection: RequestHandler = (req, res, next) => {
  if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
    const csrfToken = req.headers["x-csrf-token"] as string;
    if (!csrfToken || csrfToken !== req.session.csrfToken) {
      return res.status(403).json({ message: "Token CSRF inválido" });
    }
  }
  next();
};

// Middleware: Role-based access control
export function requireRole(...allowedRoles: string[]): RequestHandler {
  return (req, res, next) => {
    const userRole = req.session.userRole;
    if (!userRole || !allowedRoles.includes(userRole)) {
      return res.status(403).json({ message: "Acesso negado" });
    }
    next();
  };
}

// Role hierarchy helpers
export const ROLE_HIERARCHY = {
  admin: 3,
  gerente: 2,
  funcionario: 1,
};

export function canManageRole(currentRole: string, targetRole: string): boolean {
  const currentLevel = ROLE_HIERARCHY[currentRole as keyof typeof ROLE_HIERARCHY] || 0;
  const targetLevel = ROLE_HIERARCHY[targetRole as keyof typeof ROLE_HIERARCHY] || 0;
  return currentLevel > targetLevel;
}

export function canDeleteUser(currentRole: string, targetRole: string): boolean {
  // Only admin can delete users, and they cannot delete other admins
  if (currentRole !== "admin") return false;
  if (targetRole === "admin") return false;
  return true;
}

export function canViewFinancialData(role: string): boolean {
  return role === "admin" || role === "gerente";
}
