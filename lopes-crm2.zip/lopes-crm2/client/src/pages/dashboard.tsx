import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { 
  Users, 
  FolderKanban, 
  CheckSquare, 
  DollarSign,
  TrendingUp,
  Clock,
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  Palette,
  Globe,
  BarChart,
  Sparkles,
  Zap
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { canViewFinancials } from "@/lib/authUtils";
import type { Client, Project, Task, Revenue } from "@shared/schema";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart as ReBarChart,
  Bar,
} from "recharts";

interface DashboardStats {
  totalClients: number;
  activeProjects: number;
  pendingTasks: number;
  totalRevenue: number;
  recentClients: Client[];
  recentProjects: Project[];
  recentTasks: Task[];
  monthlyRevenue: { month: string; revenue: number }[];
  projectsByType: { type: string; count: number }[];
  projectsByStatus: { status: string; count: number }[];
}

const projectTypeLabels: Record<string, string> = {
  design_grafico: "Design Gráfico",
  site_sistema: "Sites & Sistemas",
  gestao_trafego: "Gestão de Tráfego",
};

const projectStatusLabels: Record<string, string> = {
  orcamento: "Orçamento",
  em_andamento: "Em Andamento",
  revisao: "Revisão",
  concluido: "Concluído",
  cancelado: "Cancelado",
};

const statusColors: Record<string, string> = {
  orcamento: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  em_andamento: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  revisao: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  concluido: "bg-green-500/20 text-green-400 border-green-500/30",
  cancelado: "bg-red-500/20 text-red-400 border-red-500/30",
};

const CHART_COLORS = [
  "#8b5cf6",
  "#06b6d4",
  "#f59e0b",
  "#10b981",
  "#ec4899",
];

function formatCurrency(value: number | string): string {
  const num = typeof value === "string" ? parseFloat(value) : value;
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(num);
}

function MetricCard({
  title,
  value,
  icon: Icon,
  trend,
  trendValue,
  loading,
  gradient,
  delay = 0,
}: {
  title: string;
  value: string | number;
  icon: React.ElementType;
  trend?: "up" | "down";
  trendValue?: string;
  loading?: boolean;
  gradient: string;
  delay?: number;
}) {
  if (loading) {
    return (
      <Card className="bg-[#12121a] border-white/10">
        <CardContent className="p-6">
          <Skeleton className="h-4 w-24 mb-2 bg-white/10" />
          <Skeleton className="h-8 w-32 bg-white/10" />
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="bg-[#12121a] border-white/10 hover:border-white/20 transition-all duration-300 overflow-hidden group">
        <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br ${gradient}`} />
        <CardContent className="p-6 relative">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">{title}</p>
              <p className="text-3xl font-bold text-white mt-1">{value}</p>
              {trend && trendValue && (
                <div className="flex items-center gap-1 mt-2">
                  {trend === "up" ? (
                    <ArrowUpRight className="h-4 w-4 text-green-400" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 text-red-400" />
                  )}
                  <span
                    className={`text-xs font-medium ${
                      trend === "up" ? "text-green-400" : "text-red-400"
                    }`}
                  >
                    {trendValue}
                  </span>
                </div>
              )}
            </div>
            <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-lg`}>
              <Icon className="h-7 w-7 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ProjectTypeIcon({ type }: { type: string }) {
  switch (type) {
    case "design_grafico":
      return <Palette className="h-4 w-4" />;
    case "site_sistema":
      return <Globe className="h-4 w-4" />;
    case "gestao_trafego":
      return <BarChart className="h-4 w-4" />;
    default:
      return <FolderKanban className="h-4 w-4" />;
  }
}

export default function Dashboard() {
  const { user } = useAuth();
  const showFinancials = canViewFinancials(user?.role);

  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  return (
    <div className="min-h-screen bg-[#0a0a0f] p-6 md:p-8 space-y-8">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-purple-900/10 via-transparent to-transparent pointer-events-none" />
      
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative"
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20">
            <Sparkles className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-purple-300">Dashboard</span>
          </div>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold text-white">
          Bem-vindo de volta, <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">{user?.firstName || "Usuário"}</span>
        </h1>
        <p className="text-gray-400 mt-2">
          Aqui está o resumo da sua agência
        </p>
      </motion.div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 relative">
        <MetricCard
          title="Total de Clientes"
          value={stats?.totalClients || 0}
          icon={Users}
          trend="up"
          trendValue="+12% este mês"
          loading={isLoading}
          gradient="from-blue-600 to-cyan-500"
          delay={0.1}
        />
        <MetricCard
          title="Projetos Ativos"
          value={stats?.activeProjects || 0}
          icon={FolderKanban}
          trend="up"
          trendValue="+5% este mês"
          loading={isLoading}
          gradient="from-purple-600 to-pink-500"
          delay={0.2}
        />
        <MetricCard
          title="Tarefas Pendentes"
          value={stats?.pendingTasks || 0}
          icon={CheckSquare}
          loading={isLoading}
          gradient="from-orange-500 to-amber-500"
          delay={0.3}
        />
        {showFinancials && (
          <MetricCard
            title="Receita Total"
            value={formatCurrency(stats?.totalRevenue || 0)}
            icon={DollarSign}
            trend="up"
            trendValue="+18% este mês"
            loading={isLoading}
            gradient="from-green-500 to-emerald-500"
            delay={0.4}
          />
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3 relative">
        {showFinancials && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="lg:col-span-2"
          >
            <Card className="bg-[#12121a] border-white/10">
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center gap-2 text-white">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500/20 to-pink-500/20">
                    <TrendingUp className="h-5 w-5 text-purple-400" />
                  </div>
                  Receita Mensal
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-64 w-full bg-white/10" />
                ) : !stats?.monthlyRevenue || stats.monthlyRevenue.length === 0 ? (
                  <div className="flex flex-col items-center justify-center min-h-[280px] text-gray-400">
                    <TrendingUp className="h-12 w-12 mb-4 opacity-50" />
                    <p>Sem dados disponíveis</p>
                  </div>
                ) : (
                  <div className="min-h-[280px]">
                    <ResponsiveContainer width="100%" height={280}>
                      <AreaChart data={stats.monthlyRevenue}>
                        <defs>
                          <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                            <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis
                          dataKey="month"
                          tick={{ fill: "#9ca3af", fontSize: 12 }}
                          axisLine={{ stroke: "rgba(255,255,255,0.1)" }}
                        />
                        <YAxis
                          tick={{ fill: "#9ca3af", fontSize: 12 }}
                          axisLine={{ stroke: "rgba(255,255,255,0.1)" }}
                          tickFormatter={(value) =>
                            new Intl.NumberFormat("pt-BR", {
                              notation: "compact",
                              compactDisplay: "short",
                            }).format(value)
                          }
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1a1a2e",
                            border: "1px solid rgba(255,255,255,0.1)",
                            borderRadius: "12px",
                            boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
                          }}
                          labelStyle={{ color: "#fff" }}
                          formatter={(value: number) => [formatCurrency(value), "Receita"]}
                        />
                        <Area
                          type="monotone"
                          dataKey="revenue"
                          stroke="#8b5cf6"
                          strokeWidth={3}
                          fillOpacity={1}
                          fill="url(#colorRevenue)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className={showFinancials ? "" : "lg:col-span-2"}
        >
          <Card className="bg-[#12121a] border-white/10">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-white">
                <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500/20 to-cyan-500/20">
                  <FolderKanban className="h-5 w-5 text-blue-400" />
                </div>
                Projetos por Tipo
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-64 w-full bg-white/10" />
              ) : !stats?.projectsByType || stats.projectsByType.length === 0 ? (
                <div className="flex flex-col items-center justify-center min-h-[280px] text-gray-400">
                  <FolderKanban className="h-12 w-12 mb-4 opacity-50" />
                  <p>Sem dados disponíveis</p>
                </div>
              ) : (
                <>
                  <div className="min-h-[280px]">
                    <ResponsiveContainer width="100%" height={280}>
                      <PieChart>
                        <Pie
                          data={stats.projectsByType}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="count"
                          nameKey="type"
                        >
                          {stats.projectsByType.map((entry, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={CHART_COLORS[index % CHART_COLORS.length]}
                            />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1a1a2e",
                            border: "1px solid rgba(255,255,255,0.1)",
                            borderRadius: "12px",
                            boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
                          }}
                          formatter={(value: number, name: string) => [
                            value,
                            projectTypeLabels[name] || name,
                          ]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex flex-wrap gap-4 justify-center mt-4">
                    {stats.projectsByType.map((item, index) => (
                      <div key={item.type} className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}
                        />
                        <span className="text-sm text-gray-400">
                          {projectTypeLabels[item.type] || item.type}
                        </span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
        >
          <Card className="bg-[#12121a] border-white/10">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-white">
                <div className="p-2 rounded-lg bg-gradient-to-br from-orange-500/20 to-amber-500/20">
                  <Clock className="h-5 w-5 text-orange-400" />
                </div>
                Projetos Recentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-16 w-full bg-white/10" />
                  ))}
                </div>
              ) : stats?.recentProjects && stats.recentProjects.length > 0 ? (
                <div className="space-y-3">
                  {stats.recentProjects.slice(0, 5).map((project, index) => (
                    <motion.div
                      key={project.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 * index }}
                      className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all duration-300"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
                          <ProjectTypeIcon type={project.type} />
                        </div>
                        <div>
                          <p className="font-medium text-white">{project.name}</p>
                          <p className="text-sm text-gray-400">
                            {projectTypeLabels[project.type]}
                          </p>
                        </div>
                      </div>
                      <Badge className={`${statusColors[project.status]} border`}>
                        {projectStatusLabels[project.status]}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                  <FolderKanban className="h-12 w-12 mb-4 opacity-50" />
                  <p>Nenhum projeto recente</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
        >
          <Card className="bg-[#12121a] border-white/10">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-white">
                <div className="p-2 rounded-lg bg-gradient-to-br from-red-500/20 to-rose-500/20">
                  <AlertCircle className="h-5 w-5 text-red-400" />
                </div>
                Tarefas Pendentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-16 w-full bg-white/10" />
                  ))}
                </div>
              ) : stats?.recentTasks && stats.recentTasks.length > 0 ? (
                <div className="space-y-3">
                  {stats.recentTasks.slice(0, 5).map((task, index) => (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 * index }}
                      className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all duration-300"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`h-3 w-3 rounded-full ${
                            task.priority === "urgente"
                              ? "bg-red-500 shadow-lg shadow-red-500/50"
                              : task.priority === "alta"
                              ? "bg-orange-500 shadow-lg shadow-orange-500/50"
                              : task.priority === "media"
                              ? "bg-blue-500 shadow-lg shadow-blue-500/50"
                              : "bg-green-500 shadow-lg shadow-green-500/50"
                          }`}
                        />
                        <div>
                          <p className="font-medium text-white">{task.title}</p>
                          <p className="text-sm text-gray-400">
                            {task.dueDate
                              ? new Date(task.dueDate).toLocaleDateString("pt-BR")
                              : "Sem prazo"}
                          </p>
                        </div>
                      </div>
                      <Badge className={`${
                        task.priority === "urgente"
                          ? "bg-red-500/20 text-red-400 border-red-500/30"
                          : task.priority === "alta"
                          ? "bg-orange-500/20 text-orange-400 border-orange-500/30"
                          : task.priority === "media"
                          ? "bg-blue-500/20 text-blue-400 border-blue-500/30"
                          : "bg-green-500/20 text-green-400 border-green-500/30"
                      } border`}>
                        {task.priority === "urgente"
                          ? "Urgente"
                          : task.priority === "alta"
                          ? "Alta"
                          : task.priority === "media"
                          ? "Média"
                          : "Baixa"}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                  <CheckSquare className="h-12 w-12 mb-4 opacity-50" />
                  <p>Nenhuma tarefa pendente</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.9 }}
      >
        <Card className="bg-[#12121a] border-white/10">
          <CardHeader>
            <CardTitle className="text-lg font-semibold flex items-center gap-2 text-white">
              <div className="p-2 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20">
                <Zap className="h-5 w-5 text-green-400" />
              </div>
              Status dos Projetos
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-48 w-full bg-white/10" />
            ) : !stats?.projectsByStatus || stats.projectsByStatus.length === 0 ? (
              <div className="flex flex-col items-center justify-center min-h-[200px] text-gray-400">
                <Zap className="h-12 w-12 mb-4 opacity-50" />
                <p>Sem dados disponíveis</p>
              </div>
            ) : (
              <div className="min-h-[200px]">
                <ResponsiveContainer width="100%" height={200}>
                  <ReBarChart data={stats.projectsByStatus} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis type="number" tick={{ fill: "#9ca3af", fontSize: 12 }} />
                    <YAxis
                      type="category"
                      dataKey="status"
                      tick={{ fill: "#9ca3af", fontSize: 12 }}
                      tickFormatter={(value) => projectStatusLabels[value] || value}
                      width={100}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1a1a2e",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: "12px",
                        boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
                      }}
                      formatter={(value: number, name: string) => [value, "Projetos"]}
                      labelFormatter={(label) => projectStatusLabels[label] || label}
                    />
                    <Bar dataKey="count" fill="#8b5cf6" radius={[0, 8, 8, 0]} />
                  </ReBarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
