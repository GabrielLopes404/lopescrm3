import type { Express, Request, Response } from "express";
import type { Server } from "http";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, requireRole, canDeleteUser, canViewFinancialData, hashPassword } from "./auth";
import { 
  insertClientSchema, 
  insertProjectSchema, 
  insertTaskSchema, 
  insertGoalSchema,
  insertRevenueSchema,
  insertUserSchema 
} from "@shared/schema";
import { z } from "zod";

// Rate limiter for API requests
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window
  message: { message: "Muitas requisições. Tente novamente em 15 minutos." },
  standardHeaders: true,
  legacyHeaders: false,
});

// Stricter rate limiter for auth routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 attempts per window
  message: { message: "Muitas tentativas de login. Tente novamente em 15 minutos." },
  standardHeaders: true,
  legacyHeaders: false,
});

// Input sanitization helper
function sanitizeString(input: string | undefined | null): string {
  if (!input) return "";
  return input.replace(/[<>]/g, "").trim();
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<void> {
  // Security headers - relaxed in development for Vite HMR
  if (process.env.NODE_ENV === "production") {
    app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'"],
          imgSrc: ["'self'", "data:", "blob:"],
          connectSrc: ["'self'"],
          fontSrc: ["'self'"],
          objectSrc: ["'none'"],
          mediaSrc: ["'self'"],
          frameSrc: ["'none'"],
        },
      },
      crossOriginEmbedderPolicy: false,
    }));
  } else {
    app.use(helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
    }));
  }

  // Apply rate limiters
  app.use("/api/auth/login", authLimiter);
  app.use("/api", apiLimiter);

  // Auth middleware
  await setupAuth(app);

  // ========== USER MANAGEMENT ROUTES ==========
  
  // Get all users (admin and gerente only)
  app.get("/api/users", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const usersList = await storage.getUsers();
      // Remove passwords from response
      const usersWithoutPasswords = usersList.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Erro ao buscar usuários" });
    }
  });

  // Create new user (admin only)
  app.post("/api/users", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const validation = insertUserSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Dados inválidos",
          errors: validation.error.flatten().fieldErrors 
        });
      }

      const { email, password, firstName, lastName, role } = validation.data;

      // Check if email already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ message: "Email já cadastrado" });
      }

      // Hash password
      const hashedPassword = await hashPassword(password);

      const user = await storage.createUser({
        email: sanitizeString(email).toLowerCase(),
        password: hashedPassword,
        firstName: sanitizeString(firstName),
        lastName: sanitizeString(lastName),
        role: role || "funcionario",
      });

      // Log activity
      await storage.createActivityLog({
        action: "create_user",
        entityType: "user",
        entityId: null,
        details: `Usuário ${user.email} criado`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Erro ao criar usuário" });
    }
  });

  // Update user role (admin only)
  app.patch("/api/users/:id/role", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { role } = req.body;
      if (!["admin", "gerente", "funcionario"].includes(role)) {
        return res.status(400).json({ message: "Função inválida" });
      }

      const targetUser = await storage.getUser(req.params.id);
      if (!targetUser) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      // Prevent demoting yourself
      if (req.params.id === req.session.userId && role !== "admin") {
        return res.status(403).json({ message: "Você não pode alterar sua própria função" });
      }

      const user = await storage.updateUserRole(req.params.id, role);
      
      await storage.createActivityLog({
        action: "update_user_role",
        entityType: "user",
        entityId: null,
        details: `Função do usuário ${targetUser.email} alterada para ${role}`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      const { password: _, ...userWithoutPassword } = user!;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Erro ao atualizar função" });
    }
  });

  // Deactivate user (admin only, cannot deactivate admin)
  app.delete("/api/users/:id", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const targetUser = await storage.getUser(req.params.id);
      if (!targetUser) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      // Cannot delete yourself
      if (req.params.id === req.session.userId) {
        return res.status(403).json({ message: "Você não pode excluir sua própria conta" });
      }

      // Cannot delete admin
      if (!canDeleteUser(req.session.userRole!, targetUser.role)) {
        return res.status(403).json({ message: "Você não pode excluir um administrador" });
      }

      await storage.deleteUser(req.params.id);
      
      await storage.createActivityLog({
        action: "delete_user",
        entityType: "user",
        entityId: null,
        details: `Usuário ${targetUser.email} desativado`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Erro ao excluir usuário" });
    }
  });

  // ========== DASHBOARD ROUTES ==========

  app.get("/api/dashboard/stats", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const stats = await storage.getDashboardStats();
      
      // Funcionario cannot see financial data
      if (!canViewFinancialData(req.session.userRole!)) {
        delete stats.totalRevenue;
        delete stats.monthlyRevenue;
      }
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Erro ao buscar estatísticas" });
    }
  });

  // ========== REPORTS ROUTES ==========

  app.get("/api/reports", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const months = parseInt(req.query.period as string) || 12;
      const reportData = await storage.getReportData(months);
      res.json(reportData);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Erro ao buscar relatórios" });
    }
  });

  // ========== CLIENT ROUTES ==========

  app.get("/api/clients", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const clientsList = await storage.getClients();
      res.json(clientsList);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ message: "Erro ao buscar clientes" });
    }
  });

  app.get("/api/clients/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const client = await storage.getClient(id);
      if (!client) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }
      res.json(client);
    } catch (error) {
      console.error("Error fetching client:", error);
      res.status(500).json({ message: "Erro ao buscar cliente" });
    }
  });

  app.post("/api/clients", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const validation = insertClientSchema.safeParse({
        ...req.body,
        createdById: req.session.userId,
      });
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Dados inválidos",
          errors: validation.error.flatten().fieldErrors 
        });
      }

      const client = await storage.createClient(validation.data);
      
      await storage.createActivityLog({
        action: "create_client",
        entityType: "client",
        entityId: client.id,
        details: `Cliente ${client.name} criado`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(201).json(client);
    } catch (error) {
      console.error("Error creating client:", error);
      res.status(500).json({ message: "Erro ao criar cliente" });
    }
  });

  app.patch("/api/clients/:id", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const client = await storage.updateClient(id, req.body);
      if (!client) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }

      await storage.createActivityLog({
        action: "update_client",
        entityType: "client",
        entityId: client.id,
        details: `Cliente ${client.name} atualizado`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.json(client);
    } catch (error) {
      console.error("Error updating client:", error);
      res.status(500).json({ message: "Erro ao atualizar cliente" });
    }
  });

  app.delete("/api/clients/:id", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const client = await storage.getClient(id);
      if (!client) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }

      await storage.deleteClient(id);

      await storage.createActivityLog({
        action: "delete_client",
        entityType: "client",
        entityId: id,
        details: `Cliente ${client.name} excluído`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting client:", error);
      res.status(500).json({ message: "Erro ao excluir cliente" });
    }
  });

  // ========== PROJECT ROUTES ==========

  app.get("/api/projects", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectsList = await storage.getProjects();
      
      const projectsWithClients = await Promise.all(
        projectsList.map(async (project) => {
          const client = await storage.getClient(project.clientId);
          const assignedTo = project.assignedToId 
            ? await storage.getUser(project.assignedToId) 
            : null;
          
          // Hide financial data from funcionario
          const projectData = !canViewFinancialData(req.session.userRole!) 
            ? { ...project, value: undefined } 
            : project;
            
          return { 
            ...projectData, 
            client, 
            assignedTo: assignedTo ? { 
              id: assignedTo.id, 
              firstName: assignedTo.firstName, 
              lastName: assignedTo.lastName 
            } : null 
          };
        })
      );
      
      res.json(projectsWithClients);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Erro ao buscar projetos" });
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Projeto não encontrado" });
      }
      
      // Hide financial data from funcionario
      if (!canViewFinancialData(req.session.userRole!)) {
        const { value, ...projectWithoutValue } = project;
        return res.json(projectWithoutValue);
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Erro ao buscar projeto" });
    }
  });

  app.post("/api/projects", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const validation = insertProjectSchema.safeParse({
        ...req.body,
        createdById: req.session.userId,
      });
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Dados inválidos",
          errors: validation.error.flatten().fieldErrors 
        });
      }

      const project = await storage.createProject(validation.data);
      
      await storage.createActivityLog({
        action: "create_project",
        entityType: "project",
        entityId: project.id,
        details: `Projeto ${project.name} criado`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(201).json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(500).json({ message: "Erro ao criar projeto" });
    }
  });

  app.patch("/api/projects/:id", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const project = await storage.updateProject(id, req.body);
      if (!project) {
        return res.status(404).json({ message: "Projeto não encontrado" });
      }

      await storage.createActivityLog({
        action: "update_project",
        entityType: "project",
        entityId: project.id,
        details: `Projeto ${project.name} atualizado`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.json(project);
    } catch (error) {
      console.error("Error updating project:", error);
      res.status(500).json({ message: "Erro ao atualizar projeto" });
    }
  });

  app.delete("/api/projects/:id", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Projeto não encontrado" });
      }

      await storage.deleteProject(id);

      await storage.createActivityLog({
        action: "delete_project",
        entityType: "project",
        entityId: id,
        details: `Projeto ${project.name} excluído`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting project:", error);
      res.status(500).json({ message: "Erro ao excluir projeto" });
    }
  });

  // ========== TASK ROUTES ==========

  app.get("/api/tasks", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const tasksList = await storage.getTasks();
      
      const tasksWithRelations = await Promise.all(
        tasksList.map(async (task) => {
          const project = task.projectId ? await storage.getProject(task.projectId) : null;
          const client = task.clientId ? await storage.getClient(task.clientId) : null;
          const assignedTo = task.assignedToId ? await storage.getUser(task.assignedToId) : null;
          const createdBy = task.createdById ? await storage.getUser(task.createdById) : null;
          return { 
            ...task, 
            project: project ? { id: project.id, name: project.name } : null, 
            client: client ? { id: client.id, name: client.name } : null, 
            assignedTo: assignedTo ? { id: assignedTo.id, firstName: assignedTo.firstName, lastName: assignedTo.lastName } : null, 
            createdBy: createdBy ? { id: createdBy.id, firstName: createdBy.firstName, lastName: createdBy.lastName } : null 
          };
        })
      );
      
      res.json(tasksWithRelations);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Erro ao buscar tarefas" });
    }
  });

  app.get("/api/tasks/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Tarefa não encontrada" });
      }
      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Erro ao buscar tarefa" });
    }
  });

  app.post("/api/tasks", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const validation = insertTaskSchema.safeParse({
        ...req.body,
        createdById: req.session.userId,
      });
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Dados inválidos",
          errors: validation.error.flatten().fieldErrors 
        });
      }

      const task = await storage.createTask(validation.data);
      
      await storage.createActivityLog({
        action: "create_task",
        entityType: "task",
        entityId: task.id,
        details: `Tarefa ${task.title} criada`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(201).json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Erro ao criar tarefa" });
    }
  });

  app.patch("/api/tasks/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const task = await storage.updateTask(id, req.body);
      if (!task) {
        return res.status(404).json({ message: "Tarefa não encontrada" });
      }

      await storage.createActivityLog({
        action: "update_task",
        entityType: "task",
        entityId: task.id,
        details: `Tarefa ${task.title} atualizada`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Erro ao atualizar tarefa" });
    }
  });

  app.delete("/api/tasks/:id", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Tarefa não encontrada" });
      }

      await storage.deleteTask(id);

      await storage.createActivityLog({
        action: "delete_task",
        entityType: "task",
        entityId: id,
        details: `Tarefa ${task.title} excluída`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Erro ao excluir tarefa" });
    }
  });

  // ========== GOAL ROUTES ==========

  app.get("/api/goals", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const year = req.query.year ? parseInt(req.query.year as string) : undefined;
      const goalsList = await storage.getGoals(year);
      res.json(goalsList);
    } catch (error) {
      console.error("Error fetching goals:", error);
      res.status(500).json({ message: "Erro ao buscar metas" });
    }
  });

  app.get("/api/goals/:id", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const goal = await storage.getGoal(id);
      if (!goal) {
        return res.status(404).json({ message: "Meta não encontrada" });
      }
      res.json(goal);
    } catch (error) {
      console.error("Error fetching goal:", error);
      res.status(500).json({ message: "Erro ao buscar meta" });
    }
  });

  app.post("/api/goals", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const validation = insertGoalSchema.safeParse({
        ...req.body,
        createdById: req.session.userId,
      });
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Dados inválidos",
          errors: validation.error.flatten().fieldErrors 
        });
      }

      const goal = await storage.createGoal(validation.data);
      
      await storage.createActivityLog({
        action: "create_goal",
        entityType: "goal",
        entityId: goal.id,
        details: `Meta ${goal.title} criada`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(201).json(goal);
    } catch (error) {
      console.error("Error creating goal:", error);
      res.status(500).json({ message: "Erro ao criar meta" });
    }
  });

  app.patch("/api/goals/:id", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const goal = await storage.updateGoal(id, req.body);
      if (!goal) {
        return res.status(404).json({ message: "Meta não encontrada" });
      }

      await storage.createActivityLog({
        action: "update_goal",
        entityType: "goal",
        entityId: goal.id,
        details: `Meta ${goal.title} atualizada`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.json(goal);
    } catch (error) {
      console.error("Error updating goal:", error);
      res.status(500).json({ message: "Erro ao atualizar meta" });
    }
  });

  app.delete("/api/goals/:id", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }

      const goal = await storage.getGoal(id);
      if (!goal) {
        return res.status(404).json({ message: "Meta não encontrada" });
      }

      await storage.deleteGoal(id);

      await storage.createActivityLog({
        action: "delete_goal",
        entityType: "goal",
        entityId: id,
        details: `Meta ${goal.title} excluída`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting goal:", error);
      res.status(500).json({ message: "Erro ao excluir meta" });
    }
  });

  // ========== REVENUE ROUTES ==========

  app.get("/api/revenues", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const revenuesList = await storage.getRevenues();
      res.json(revenuesList);
    } catch (error) {
      console.error("Error fetching revenues:", error);
      res.status(500).json({ message: "Erro ao buscar receitas" });
    }
  });

  app.post("/api/revenues", isAuthenticated, requireRole("admin", "gerente"), async (req: Request, res: Response) => {
    try {
      const validation = insertRevenueSchema.safeParse({
        ...req.body,
        createdById: req.session.userId,
      });
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Dados inválidos",
          errors: validation.error.flatten().fieldErrors 
        });
      }

      const revenue = await storage.createRevenue(validation.data);
      
      await storage.createActivityLog({
        action: "create_revenue",
        entityType: "revenue",
        entityId: revenue.id,
        details: `Receita ${revenue.description} registrada`,
        ipAddress: req.ip || "unknown",
        userAgent: req.get("User-Agent") || "unknown",
        userId: req.session.userId!,
      });

      res.status(201).json(revenue);
    } catch (error) {
      console.error("Error creating revenue:", error);
      res.status(500).json({ message: "Erro ao registrar receita" });
    }
  });

  // ========== ACTIVITY LOGS ==========

  app.get("/api/activity-logs", isAuthenticated, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const logs = await storage.getActivityLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching activity logs:", error);
      res.status(500).json({ message: "Erro ao buscar logs de atividade" });
    }
  });
}
